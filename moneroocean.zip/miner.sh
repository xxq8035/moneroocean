#!/bin/bash
if ! pidof xin>/dev/null; then
  nice /root/moneroocean/xin $*
else
  echo "Monero miner is already running in the background. Refusing to run another one."
  echo "Run \"killall xin\" or \"sudo killall xin\" if you want to remove background miner first."
fi
