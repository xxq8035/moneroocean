import time
import random
import requests  # 确保导入requests库

# 设置文件名
filename = "activity_indicator.txt"

# 模拟的代码片段列表
code_snippets = [
    "# 基本的GET请求\nresponse = requests.get('https://api.github.com')\nprint(response.status_code)",
    "# 带参数的GET请求\nparams = {'q': 'galaxy', 'page': 1}\nresponse = requests.get('https://api.github.com/search/repositories', params=params)\nprint(response.json())",
    "# POST请求\ndata = {'key': 'value'}\nresponse = requests.post('https://httpbin.org/post', data=data)\nprint(response.json())",
    "# GET请求并检查响应内容\nresponse = requests.get('https://api.github.com')\nif response.status_code == 200:\n    print(response.json())",
    "# 发送请求并设置自定义头部\nheaders = {'User-Agent': 'My App'}\nresponse = requests.get('https://api.github.com', headers=headers)\nprint(response.status_code)",
    "# 发送请求到API并获取JSON响应\nresponse = requests.get('https://jsonplaceholder.typicode.com/todos/1')\ntodo = response.json()\nprint(todo)",
    "# 发送POST请求并包含JSON数据\njson_data = {'title': 'example', 'body': 'this is an example', 'userId': 1}\nresponse = requests.post('https://jsonplaceholder.typicode.com/todos', json=json_data)\nprint(response.json())"
]

# 设置随机的保存间隔（秒），在2到8分钟之间
interval = random.randint(120, 480)

def save_activity():
    # 随机选择一个代码片段
    snippet = random.choice(code_snippets)
    # 写入文件
    with open(filename, "a") as file:
        file.write(f"{snippet}\n\n")

while True:
    save_activity()
    time.sleep(interval)